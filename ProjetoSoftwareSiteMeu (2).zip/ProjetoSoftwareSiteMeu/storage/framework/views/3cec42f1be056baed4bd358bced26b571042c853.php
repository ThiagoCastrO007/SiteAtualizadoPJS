

<?php $__env->startSection('conteudo'); ?>
<div id="cabecalhoLogin">
        <h1 id="cabcalhoLogin1">Pagina de Dúvidas</h1>
        <form action="">
        <h2>Informe sua dúvida</h2>
        <input type="text" id="email-input" placeholder="DIGITE SUA DÚVIDA">    
        <button onclick="alert('Sua duvida ja foi enviada')">enviar</button>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Cotemig\site\SiteMeuuu\resources\views/Duvidas.blade.php ENDPATH**/ ?>